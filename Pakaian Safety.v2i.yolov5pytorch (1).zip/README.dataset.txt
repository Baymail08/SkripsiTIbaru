# Pakaian Safety > 2023-01-02 10:52pm
https://universe.roboflow.com/deteksi-pakaian-safety/pakaian-safety-uwyss

Provided by a Roboflow user
License: CC BY 4.0

